# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 12:51:29 2020

@author: George
"""

"""
For this challenge we will need:
    1. variable assignment
    2. lists
    3. Indices
    

Make a script that does the following:
    
1. Prompts the user to enter three strings
2. Stores the results in variables
3. Creates a list containing the lengths of each string
4. Stores the list in a variable
5. Outputs the list
6. For each string, outputs
    * the length (from the stored list)
    * the first three letters
    * the last three letters
    
"""

# name three strings and think of the input() function


# add the strings to a list between square brackets - give the list a sensible name!


# print the list


# print length, first three and last three letters of any string with more that 4 letters
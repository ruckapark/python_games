# -*- coding: utf-8 -*-
"""
Created on Thu Apr  2 15:04:11 2020

Flappy Python code

@author: George
"""

import os
import pygame
import random

from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    K_SPACE,
    KEYDOWN,
    KEYUP,
    QUIT,
)

pygame.init()
screen_w,screen_h = 500,500                             #screen size
screen = pygame.display.set_mode((screen_w, screen_h))  #display screen
pygame.display.set_caption("Flappy Python")
score = 0

os.chdir('FB_pictures')
#read in our images that we will use in flappy bird as pygame images
python = pygame.image.load('flappy_python.PNG')
bg = pygame.image.load('thunder_bg.jpg')

python_x = 150
python_y = screen_h//3
y_diff = 0
python_constant = 2.71*10**(-3)
acc = 9.81 * python_constant
speed = 0

class Pipe():
    
    def __init__(self):
        pass

pipe = pygame.image.load('pipe.PNG')

pipe_width = 152
pipe_height = 500
pipe_x = screen_w
pipe_y = -random.randint(100,400)
pipe_gap = 100
pipe_edge = 0 #for collision detection

bg_width = 1920*2
bg_loc = 0

def suvat(u):
    """
    so far we aren't taking into account clockspeed and times
    so we just assume time to always be 1
    
    the units of acc are pixels/clockspeed^2
    """
    global acc
    v = u + acc
    s = 0.5*(u + v)
    return v,s
    
def is_collision(x1,y1,x2,y2):
    d = ((x1 - x2)**2 + (y1 - y2)**2)**0.5
    if d < 10:
        return True
    else:
        return False

running = True
while running:
    
    #background
    screen.fill((255,255,255))
    screen.blit(bg,(bg_loc,0))
    bg_loc -= 1
    if -bg_width < bg_loc <= -bg_width + 500:
        screen.blit(bg,(bg_loc+bg_width,0))
    elif bg_loc <= -bg_width:
        bg_loc = 0
        screen.blit(bg,(bg_loc,0))
        
    #pipes
    pipe_x -= 2
    screen.blit(pipe,(pipe_x,pipe_y))
    screen.blit(pipe,(pipe_x,pipe_y + pipe_height + pipe_gap))
    if pipe_x < 0-pipe_width:
        pipe_x = screen_w
        pipe_y = -random.randint(100,400)
        score += 1
        pipe_edge = 0 
    
    for event in pygame.event.get():
        
        if event.type == QUIT:
            running = False
            
        if event.type == KEYDOWN:
            if event.key == K_SPACE:
                speed = -1.8
            
    #bird
    old_speed = speed
    speed,y_diff = suvat(old_speed)
    python_y += y_diff
    screen.blit(python, (python_x,python_y))
    
    if python_y > screen_h or python_y < -32:
        running = False
    
    if abs(pipe_x + pipe_edge - python_x) < 20:
        pipe_edge -= 2 #same as pipe speed
        if python_y < (pipe_y + pipe_height) or python_y > (pipe_y + pipe_height + pipe_gap):
            #you lose
            running = False
            
    pygame.display.update()
print(score)
pygame.quit()